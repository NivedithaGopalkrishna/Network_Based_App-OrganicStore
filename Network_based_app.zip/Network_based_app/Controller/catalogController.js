var express = require('express');
var router = express.Router();
var breadcrumbs = require('express-breadcrumb');
var appUtil = require('../utility/appUtil');
var ItemData = require('../model/item');
var itemDb = require('../utility/ItemDB');
var userDB = require('../utility/UserDB');
var bodyParser = require('body-parser');
var session = require('express-session');

var User = require('../model/User');
var UserProfile = require('../model/UserProfile');
var UserItem = require('../model/UserItem');
var ProfileController = require('./ProfileController');

var urlencodedParser = bodyParser.urlencoded({ extended: false });
var expressValidator = require('express-validator');
router.use(expressValidator());
router.use(bodyParser.json());
var { check } = require('express-validator/check');
const { validationResult } = require('express-validator/check');
router.use(bodyParser.urlencoded({
    extended: false
}));

var user = null;
var userProfile = null;

router.use(function getSession(req,res,next){
  console.log("I am executed here inside router use, get session function");
  console.log("Initial value: "+JSON.stringify(req.session.theUser));
  if(req.session.theUser){
    var temp = req.session.theUser;
    console.log("Temp: "+JSON.stringify(temp));

    user = new User.User(temp.userId,temp.firstName,temp.lastName,temp.email,temp.addr1,temp.addr2,temp.city,temp.state,temp.zipCode,temp.country);

    userProfile = new UserProfile(temp.userId);

    for (var j = 0; j < temp.user_item.length; j++) {
      var userItem = new UserItem(temp.user_item[j].itemCode,
          temp.user_item[j].itemName,
          temp.user_item[j].rating,
          temp.user_item[j].madeIt,
          temp.user_item[j].catalogCategory);

      userProfile.addItem(userItem);
  }
}//end of if
  else{
    user = null;
    userProfile = null;
  }

next();

});


router.post('/check',urlencodedParser,function(req,res){
  var username = req.body.username;
  var password = req.body.password;

  req.check('username').isEmail().withMessage('Enter a valid Email address');
  req.check('password').isNumeric({no_symbols:true}).isLength({min:3,max:9}).withMessage("Enter a valid password");

  var errors = req.validationErrors();
  if(errors){
    for(var i=0;i<errors.length;i++){
      console.log("Error: "+errors[i].msg);
    }
    var data = {
            title: ' ',
            path: req.url,
            user:null
        };
    var message = "Either Username or Password is incorrect. Please try again";
    res.render('login',{message:message,data:data});
  }
  else{
    console.log("UserName: "+username+" Password: "+password);
    User.UserModel.findOne({email:username,password:password})
      .then(function(doc){
        // if(doc==null){
        //   console.log("Empty!!");
        //   res.redirect('/myItems/signIn');
        //
        // }
        // else {
        //   console.log("Data: "+doc);
        //   res.redirect('/');
        //
        // }
        if(doc!=null){
          console.log("User data: "+doc.user_item);
          req.session.currentProfile = doc.user_item;
          req.session.theUser = doc;
          console.log("Session data: "+req.session.theUser);
          var data = {
                  title: ' ',
                  path: req.url,
                  user: user,
                  userProfile: userProfile
              };
          res.redirect('/myItem');
        }
        else {

          var data = {
                  title: ' ',
                  path: req.url,
                  user:null
              };
          var message = "Either Username or Password is incorrect. Please try again"
          req.session.message = message;
          console.log("message: "+req.session.message);
          rres.render('login',{message:message,data:data});
        }

      });

  }

});



//Function to fetch all the items from the database
var getAllItems = new Promise(function(resolve,reject){
  var items = [];
    ItemData.ItemModel.find()
    .then(function(doc){
      for(var i=0;i<doc.length;i++){
        var item = new ItemData.Item(doc[i].itemCode,
                doc[i].itemName,
                doc[i].catalogCategory,
                doc[i].description,
                doc[i].rating,
                doc[i].imageURL);

          items.push(item);

      }
      resolve(doc);
      return items;

    }).catch(function(err){
      reject(err);
    });

});


router.post('/update/feedback/:itemCode',function(req,res){
  console.log("Item Rating: "+req.body.rating);
  var rating = req.body.rating;
  var itemCode = req.body.itemCode;
  var temp = req.session.theUser;
  var madeIt = req.body.madeItRadio;

  //console.log("User id inside feedback/update: "+temp[0].userId);
  if(req.session.theUser){
    var userId = temp.userId;
    User.UserModel.findOne({userId: userId,'user_item.itemCode':itemCode})
        .then(function(doc){
            if(doc!=null){
                if(req.body.feedbackHidden == 'rating'){
                    addItemRating(itemCode,userId,rating).then(function(doc){
                        ItemData.ItemModel.findOneAndUpdate({itemCode:itemCode},{$set:{rating:rating}},{new:true}).then(function(doc){
                              console.log("Data inside udpate: "+doc);
                            });
                            req.session.theUser = doc;
                            res.redirect('/myItem');
                          });
                        }
                        else if(req.body.feedbackHidden == 'madeIt'){
                          addMadeIt(itemCode,userId,madeIt).then(function(doc){
                            req.session.theUser = doc;
                            res.redirect('/myItem');
                          });
                        }
                      }
              else{
                console.log("Cannot Rate Item which is not present with User!");
                res.redirect('/myItem');
              }
            });
  }
  else{
    var userId = 11;
    User.UserModel.findOne({userId: userId,'user_item.itemCode':itemCode})
        .then(function(doc){
            if(doc!=null){
                if(req.body.feedbackHidden == 'rating'){
                    addItemRating(itemCode,userId,rating).then(function(doc){
                      ItemData.ItemModel.findOneAndUpdate({itemCode:itemCode},{$set:{rating:rating}},{new:true}).then(function(doc){
                            console.log("Data inside udpate: "+doc);
                          });
                            req.session.theUser = doc;
                            res.redirect('/myItem');
                          });
                        }
                        else if(req.body.feedbackHidden == 'madeIt'){
                          addMadeIt(itemCode,userId,madeIt).then(function(doc){
                            req.session.theUser = doc;
                            res.redirect('/myItem');
                          });
                        }
                  }
              else{
                console.log("Cannot rate item which is not present with the User");
                res.redirect('/myItem');
              }
        });

  }

});



router.get('/myItem/delete/:itemCode', function (req, res) {
  let itemCode = req.params.itemCode;
  var temp = req.session.theUser;
  console.log("Item code insdie delete: "+itemCode);
  console.log("temp inside delete: "+temp.userId);
  var id = temp.userId;
  User.UserModel.findOneAndUpdate({userId: id},
  {$pull:{user_item: {itemCode: itemCode}}},{new:true})
  .then(function(doc){
    //var data_sent = [];
    //data_sent.push(doc);
    req.session.theUser = doc;
    console.log("data deleted: "+doc);
    res.redirect('/myItem');
  });
});

router.get('/categories/item/saveIt/:itemCode',check('itemCode').isNumeric(),function(req,res){
  const errors = validationResult(req);
    if(!errors.isEmpty()){
      console.log("Invalid input Error");
      return res.redirect('/categories');
    }

  let itemCode = req.params.itemCode;
  var temp = req.session.theUser;
  //console.log("User Id inside: "+temp.userId);

  //console.log("item Code in save it: "+itemCode);
  if(req.session.theUser){
    var id = temp.userId;
    User.UserModel.findOne({"user_item.itemCode":itemCode},{"user_item.$":1})
      .then(function(doc){
        if(doc==null){
          console.log("Item not present");
          getItem(itemCode).then(function(docs){

            //console.log("item details to be updated: "+docs[0].itemName);
            for(var i=0;i<docs.length;i++){
              var itemName = docs[i].itemName;
              var rating = docs[i].rating;
              var catalogCategory = docs[i].catalogCategory;
              var madeIt = false;
            }
            //console.log("item details to be updated: "+itemCode+" "+itemName+" "+rating+" "+catalogCategory+" "+madeIt);

            User.UserModel.findOneAndUpdate({userId:id},
              {$push:{user_item: {
            itemName:itemName,
            itemCode:itemCode,
            rating:rating,
            catalogCategory: catalogCategory,
            madeIt: madeIt
          }}},{new:true})
          .then(function(doc){
          //  var data_sent = [];
            //data_sent.push(doc);
            req.session.theUser = doc;
            //console.log("Req.session.theUser: "+JSON.stringify(req.session.theUser));
            res.redirect('/myItem');
          });
        });
      }
        else {
          console.log("item present already present with User!!");
          res.redirect('/myItem');
        }
    });

  }
  else{
    var userId = 11; //when session is not started we are logging in the first user
    var userDetails = ProfileController.getUser(userId);
    userDetails.then(function(doc){
      User.UserModel.findOne({userId:userId,"user_item.itemCode":itemCode},{"user_item.$":1})
        .then(function(doc){
          if(doc==null){
            console.log("Item not present");
            getItem(itemCode).then(function(docs){

              //console.log("item details to be updated: "+docs[0].itemName);
              for(var i=0;i<docs.length;i++){
                var itemName = docs[i].itemName;
                var rating = docs[i].rating;
                var catalogCategory = docs[i].catalogCategory;
                var madeIt = false;
              }
              //console.log("item details to be updated: "+itemCode+" "+itemName+" "+rating+" "+catalogCategory+" "+madeIt);

              User.UserModel.findOneAndUpdate({userId:userId},
                {$push:{user_item: {
              itemName:itemName,
              itemCode:itemCode,
              rating:rating,
              catalogCategory: catalogCategory,
              madeIt: madeIt
            }}},{new:true})
            .then(function(doc){
              req.session.theUser = doc;
              //console.log("Req.session.theUser: "+JSON.stringify(req.session.theUser));
              res.redirect('/myItem');
            });
          });
        }
          else {
            console.log("item present already present with User!!");
            res.redirect('/myItem');
          }
      });

      // req.session.theUser = doc;
      // console.log("Session inside else: "+req.session.theUser);
      // res.redirect('/myItems');
    });

  }

});

//Function to fetch item from the database
var getItem = function(itemCode){
  return new Promise(function(resolve,reject){
    var items = [];
    ItemData.ItemModel.find({itemCode:itemCode})
      .then(function(doc){
        for(var i=0;i<doc.length;i++){
          var item = new ItemData.Item(doc[i].itemCode,
                  doc[i].itemName,
                  doc[i].catalogCategory,
                  doc[i].description,
                  doc[i].rating,
                  doc[i].imageURL);
            items.push(item);
        }
        resolve(doc);
        return items;


      }).catch(function(err){
        reject(err);
      })
  });

};



router.get('/', function (req, res) {
    var data = {
        title: 'Index',
        path: req.url,
        user: user
    };
    res.render('index', {
        data: data
    });
});




router.get('/categories',breadcrumbs.Middleware(), function(req, res, next) {
  var data = {
    user: user
  };
  console.log("Item returned from getAll: "+getAllItems);
    var category =   ItemData.ItemModel.distinct('catalogCategory');
    category.then(function(doc){
      data.categories = doc;
      getAllItems.then(function(docs){
          data.items = docs;
          console.log("From getAllItems: "+data.items);
          res.render('category',{data:data});
        });
    });

});



router.get('/contact', function (req, res) {
    var data = {
        title: 'Contact',
        path: req.url,
        user: user
    };
    //console.log('user : ',data.user);
    //console.log('path : ',data.path);
    res.render('contact', {
        data: data
    });
});

router.get('/about', function (req, res) {
    var data = {
        title: 'About',
        path: req.url,
        user: user
    };
    //console.log('user : ',data.user);
    //console.log('path : ',data.path);
    res.render('about', {data: data});
});





router.get('/categories/item/:itemCode', check('itemCode').isNumeric() , function(req, res, next) {

  const errors = validationResult(req);
  if(!errors.isEmpty()){
  console.log("Invalid input Error");
  return res.redirect('/categories');
    }
        var itemCode = req.params.itemCode;
        var data = {

              title: 'Item',
              path: req.url,
              user: user

        };
        getItem(itemCode).then(function(doc){
          if(itemCode>8||itemCode<1){
            res.redirect('/categories');
          }
          else{
            data.item = doc;
            res.render('item',{data:data});
          }
});
});


router.get('/categories/feedback/:itemCode',check('itemCode').isNumeric(),function(req,res){
  const errors = validationResult(req);
    if(!errors.isEmpty()){
      console.log("Invalid input Error");
      return res.redirect('/categories');
    }
  var itemCode = req.params.itemCode;
  var data = {};
  console.log("Item Code:"+itemCode);
  getItem(itemCode).then(function(doc){
    if(itemCode>8||itemCode<1){
      res.redirect('/categories');
    }
    else{
      data.item = doc;
      res.render('feedback',{data:data});
    }
  });
});

var addItemRating = function(itemCode,userId,rating){
  return new Promise(function(resolve,reject){
    var data_sent = [];
      User.UserModel.findOneAndUpdate({userId:userId,'user_item.itemCode':itemCode},
        {$set:{'user_item.$.rating':rating}},{new:true}).then(function(doc){
          data_sent.push(doc);
          resolve(doc);
          return data_sent;
        }).catch(function(err){
          reject(err);
          console.log("Error: "+err);
        });
  })
}

var addMadeIt = function(itemCode,userId,madeIt){
  return new Promise(function(resolve,reject){
    var data_sent = [];
    User.UserModel.findOneAndUpdate({userId:userId,'user_item.itemCode':itemCode},
      {$set:{'user_item.$.madeIt':madeIt}},{new:true}).then(function(doc){
        data_sent.push(doc);
        resolve(doc);
        return data_sent;
      }).catch(function(err){
        reject(err);
        console.log("Error: "+err);
      });

  })
}


router.get('/*', function (req, res) {
    var data = {
        title: 'Error',
        path: req.url
    };
    res.render('error', {
        data: data
    });
});


var categories = [];
let getCategories = function() {
    // get the category of each item
    var data = itemDb.getItems();
    data.forEach(function (item) {
        if(!categories.includes(item.catalogCategory)){
            categories.push(item.catalogCategory);
        }

    });
    return categories;
};
module.exports = router;
