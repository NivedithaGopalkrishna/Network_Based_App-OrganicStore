var mongoose = require('mongoose');
 mongoose.connect('mongodb://localhost/new',{useNewUrlParser: true});
 mongoose.set('useFindAndModify',false);

 var db = mongoose.connection;
db.on('error',console.error.bind(console,'connection error:'));

db.once('open',function(){
  console.log("Connected!");
});

var itemSchema = new mongoose.Schema({
  itemCode: {type: Number,required: true},
  itemName: {type: String,required: true},
  catalogCategory: {type: String,required: true},
  description: {type: String,required: true},
  rating: {type: Number,required: true},
  imageURL: {type: String,required: true},
},{collection:'ItemData'});

module.exports.ItemModel = mongoose.model('itemData',itemSchema);

class Item {
    get note() {
        return this._note;
    }

    set note(value) {
        this._note = value;
    }
    /**
     * Constructor
     * @param itemCode
     * @param itemName
     * @param catalogCategory
     * @param description
     * @param rating
     * @param imageURL
     */
    constructor(itemCode, itemName, catalogCategory, description, rating, imageURL) {
        this._itemCode = itemCode;
        this._itemName = itemName;
        this._catalogCategory = catalogCategory;
        this._description = description;
        this._rating = rating;
        this._imageURL = imageURL;
    }


    get itemCode() {
        return this._itemCode;
    }

    set itemCode(value) {
        this._itemCode = value;
    }

    get itemName() {
        return this._itemName;
    }

    set itemName(value) {
        this._itemName = value;
    }

    get catalogCategory() {
        return this._catalogCategory;
    }

    set catalogCategory(value) {
        this._catalogCategory = value;
    }

    get description() {
        return this._description;
    }

    set description(value) {
        this._description = value;
    }

    get rating() {
        return this._rating;
    }

    set rating(value) {
        this._rating = value;
    }

    get imageURL() {
        return this._imageURL;
    }

    set imageURL(value) {
        this._imageURL = value;
    }


}

module.exports.Item = Item;
