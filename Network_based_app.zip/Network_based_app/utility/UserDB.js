/*var User = require('../model/User');
var UserItem = require('../model/UserItem');
//var Item = require('../model/Item');
var UserProfile = require('../model/UserProfile');

var userData = [
    {
        userId: 1,
        firstName: "Niveditha",
        lastName: "Gopalkrishna",
        email: "Ngopalk1@uncc.edu",
        address1: "9539 University Terrace Dr",
        address2: "Apt E",
        city: "Charlotte",
        state: "North Carolina",
        zipCode: 28262,
        country: "United States"
    }
];

var userProfileData = [
    {
        userId: 1,
        userItemList: [
            {
                itemCode: 1,
                itemName: 'Oganic Herb Gardening',
                catalogCategory: 'Organic Gardening',
                rating: 3,
                madeIt: true
            },
            {
                itemCode: 7,
                itemName: 'Cheese Making',
                catalogCategory: 'Organic Recipies',
                rating: 4,
                madeIt: false
            }
        ]
    }
];

module.exports.getUsers = function () {

    var users = [];
    for (var i = 0; i < userData.length; i++) {

        var user = new User(userData[i].userId,
            userData[i].firstName,
            userData[i].lastName,
            userData[i].email,
            userData[i].address1,
            userData[i].address2,
            userData[i].city,
            userData[i].state,
            userData[i].zipCode,
            userData[i].country);

        users.push(user);

    }
    return users;

};

module.exports.getUserProfiles = function() {
    var userProfiles = [];
    for (var i = 0; i < userProfileData.length; i++) {
        var userProfile = new UserProfile(userProfileData[i].userId);

        for(var j=0; j < userProfileData[i].userItemList.length; j++){
            var userItem = new UserItem(userProfileData[i].userItemList[j].itemCode,
                userProfileData[i].userItemList[j].itemName,
                userProfileData[i].userItemList[j].catalogCategory,
                userProfileData[i].userItemList[j].rating,
                userProfileData[i].userItemList[j].madeIt);

            userProfile.addItem(userItem);
        }

        userProfiles.push(userProfile);
    }
    return userProfiles;
};

module.exports.getUser = function (userId) {

    for (var i = 0; i < userData.length; i++) {
        if (parseInt(userData[i].userId) == userId) {
            var user = new User(userData[i].userId,
                userData[i].firstName,
                userData[i].lastName,
                userData[i].email,
                userData[i].address1,
                userData[i].address2,
                userData[i].city,
                userData[i].state,
                userData[i].zipCode,
                userData[i].country);

            return user;
        }
    }
};

module.exports.getUserProfile = function (userId) {

    for (var i = 0; i < userProfileData.length; i++) {
        if (parseInt(userProfileData[i].userId) == userId) {
            var userProfile = new UserProfile(userProfileData[i].userId);

            for(var j=0; j < userProfileData[i].userItemList.length; j++){
                var userItem = new UserItem(userProfileData[i].userItemList[j].itemCode,
                    userProfileData[i].userItemList[j].itemName,
                    userProfileData[i].userItemList[j].catalogCategory,
                    userProfileData[i].userItemList[j].rating,
                    userProfileData[i].userItemList[j].madeIt);

                userProfile.addItem(userItem);
            }

            return userProfile;
        }

    }
};*/
