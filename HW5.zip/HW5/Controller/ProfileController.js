var express = require('express');
var router = express.Router();
var userDB = require('../utility/UserDB');
var itemDb = require('../utility/ItemDB');

var bodyParser = require('body-parser');
var session = require('express-session');

var User = require('../model/User');
var UserProfile = require('../model/UserProfile');
var UserItem = require('../model/UserItem');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var expressValidator = require('express-validator');

router.use(expressValidator());
router.use(bodyParser.json());

router.use(bodyParser.urlencoded({
    extended: false
}));

router.use(function getSession(req,res,next){
  console.log("I am executed here inside router use, get session function");
  console.log("Initial value: "+JSON.stringify(req.session.theUser));
  if(req.session.theUser){
    var temp = req.session.theUser;
    console.log("Temp: "+JSON.stringify(temp));

    user = new User.User(temp.userId,temp.firstName,temp.lastName,temp.email,temp.addr1,temp.addr2,temp.city,temp.state,temp.zipCode,temp.country);

    userProfile = new UserProfile(temp.userId);

    for (var j = 0; j < temp.user_item.length; j++) {
      var userItem = new UserItem(temp.user_item[j].itemCode,
          temp.user_item[j].itemName,
          temp.user_item[j].rating,
          temp.user_item[j].madeIt,
          temp.user_item[j].catalogCategory);

      userProfile.addItem(userItem);
  }
}//end of if
  else{
    user = null;
    userProfile = null;
  }

next();

});

router.get('/myItem',function(req,res,next){
  if(req.session.theUser){
    console.log("Came directly after redirect");
    var data = {
            title: 'myItems',
            path: req.url,
            user: user,
            userProfile: userProfile
        };
    res.render('myItem',{data: data});
  }
  else{
    var data = {
            title: 'myItems',
            path: req.url,
            user: null,

        };
  res.render('login',{data:data});
}

  /*  console.log("Inside else part of get");
    var userId = 11;
    var userObj= getUser(userId);
    getUser(userId).then(function(doc){
      req.session.theUser = doc;


      res.redirect('/myItem');
    });
  }*/
});

router.post('/signin',function(req,res){
  if(req.session.theUser){
    var data = {
            title: 'myItems',
            path: req.url,
            user:null
        };
        req.session.isloggedin = true;
  //  res.render('myItem',{data: data});

    res.render('login',{isloggedin:false,message:null, data:data});
  }
  else {
    var message = req.session.message;
    var data = {
            title: 'myItems',
            path: req.url,
user:null
        };
        req.session.isloggedin = true;
    res.render('login',{isloggedin:false,message:message,data:data});
  }

});


router.post('/logout', function (req, res) {
    req.session.destroy();
        res.redirect('/');

});


//Function to fetch all the users from the database
var getAllUsers = new Promise(function(resolve,reject){
  let userData = [];
  User.UserModel.find()
    .then(function(doc){
        for(var i=0;i<doc.length;i++){
          var user = new User.User(doc[i].userId,
                doc[i].firstName,
                doc[i].lastName,
                doc[i].email,
                doc[i].addr1,
                doc[i].addr2,
                doc[i].city,
                doc[i].state,
                doc[i].zipCode,
                doc[i].country);
          var userItem = new UserItem(doc[i].user_item.itemCode,
                  doc[i].user_item.itemName,
                  doc[i].user_item.rating,
                  doc[i].user_item.madeIt,
                  doc[i].user_item.catalogCategory);

          var userProfile = new UserProfile(doc[i].userId);

          userData.push(user);
          userData.push(userItem);
          userProfile.addItem(userItem);
        }
        resolve(doc);
        return userData;
      }).catch(function(err){
        console.log("Error: "+err);
        reject(err);
      });

});

//Function to fetch user from the database
var getUser = function(userId){
  return new Promise(function(resolve,reject){
    var userItems = [];
    console.log("Inside getUser: "+userId);
    User.UserModel.find({userId:userId})
      .then(function(doc){
        console.log("Inside .then"+doc);
        for(var i=0;i<doc.length;i++){
          var userProfile = new UserProfile(doc[i].userId);
          var user = new User.User(doc[i].userId,
              doc[i].firstName,
              doc[i].lastName,
              doc[i].email,
              doc[i].addr1,
              doc[i].addr2,
              doc[i].city,
              doc[i].state,
              doc[i].zipCode,
              doc[i].country);
        console.log("user item length: "+doc[i].user_item.length);
        userItems.push(user);
        for(var j=0;j<doc[i].user_item.length;j++){
          var userItem = new UserItem(doc[i].user_item[j].itemCode,
                     doc[i].user_item[j].itemName,
                     doc[i].user_item[j].rating,
                     doc[i].user_item[j].madeIt,
                     doc[i].user_item[j].catalogCategory);

          userItems.push(userItem);
          userProfile.addItem(userItem);

        }
        console.log("User Item in getUser: "+JSON.stringify(userItems));
        }
        resolve(doc);
        return userItems;
      }).catch(function(err){
        console.log("Error: "+err);
        reject(doc);
      });

  });
}
var getSelectedItem = function (itemList, itemCode) {
    for (var index = 0; index < itemList.length; index++) {
        //console.log(itemList[index]._itemCode);
        //console.log(itemList[index]._itemCode == parseInt(itemCode,10));
        if (itemList[index]._itemCode == parseInt(itemCode, 10)) {
            return index;
        }
    }
    return -2;
};

module.exports.getSelectedItem = getSelectedItem;

module.exports.router = router;
